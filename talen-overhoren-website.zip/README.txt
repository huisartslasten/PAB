# Talen Overhoren

Een eenvoudige, gratis te hosten website voor het overhoren van woordjes.

## Online zetten
Upload `index.html` naar een statische hostingdienst zoals GitHub Pages, Netlify of Cloudflare Pages.
De site heeft geen database of server nodig.

## Gebruik
Voer bijvoorbeeld in:
bonjour = hallo
merci = bedankt
maison = huis

Klik daarna op **Start overhoring**. Met **Deel woordenlijst** wordt een link gemaakt die je naar klasgenoten/ouders kunt sturen.
